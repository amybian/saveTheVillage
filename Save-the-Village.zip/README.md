# Save the Village


### Project Details
Project utilizes the p5.play Javascript Library. Use the arrow keys to move the character and the mouse to interact with on-screen objects. Fill up your water bucket at the lake and water the corn plants!



## File Overview

### ← script.js

JavaScript code for the game.

### ← assets
image file storage

### ← index.html

The HTML file for webpage setup and libraries.

### ← style.css

 

